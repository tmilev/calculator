:man_page: mongoc_get_version

mongoc_get_version()
====================

Synopsis
--------

.. code-block:: c

  const char *
  mongoc_get_version (void);

Returns
-------

A string representation of libmongoc's version, formatted something like "1.2.3" or "1.2.3-dev".

