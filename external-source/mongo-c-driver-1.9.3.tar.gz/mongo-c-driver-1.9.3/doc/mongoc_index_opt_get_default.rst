:man_page: mongoc_index_opt_get_default

mongoc_index_opt_get_default()
==============================

Synopsis
--------

.. code-block:: c

  const mongoc_index_opt_t *
  mongoc_index_opt_get_default (void) BSON_GNUC_CONST;

Returns
-------

Returns a pointer to the default index creation options.

