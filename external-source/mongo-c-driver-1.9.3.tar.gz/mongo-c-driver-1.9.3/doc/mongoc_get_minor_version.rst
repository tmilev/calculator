:man_page: mongoc_get_minor_version

mongoc_get_minor_version()
==========================

Synopsis
--------

.. code-block:: c

  int
  mongoc_get_minor_version (void);

Returns
-------

The value of ``MONGOC_MINOR_VERSION`` when libmongoc was compiled.

